import os

if __name__ == '__main__':
    print 'Hello, world'
